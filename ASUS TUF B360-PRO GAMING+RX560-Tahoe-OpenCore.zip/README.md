# ASUS TUF B360-PRO GAMING + Radeon RX 560 — macOS Tahoe 26

В репозитории сохранён исходный архив с Clover и добавлена новая EFI на **OpenCore 1.0.7**:

- готовая папка: `EFI/`;
- архив для копирования: `ASUS TUF B360-PRO GAMING+RX560-Tahoe-OpenCore.zip`;
- исходный архив без изменений: `ASUS TUF B360-PRO GAMING+RX560.zip`.

## Что изменено

Старая Clover EFI 2022 года заменена отдельной конфигурацией OpenCore. Используются актуальные для Tahoe компоненты:

| Компонент | Версия |
|---|---:|
| OpenCore | 1.0.7 |
| Lilu | 1.7.2 |
| VirtualSMC | 1.3.7 |
| WhateverGreen | 1.7.0 |
| AppleALC | 1.9.7 |
| RestrictEvents | 1.1.6 |
| IntelMausi | 1.0.8 |

Добавлены SSDT для Coffee Lake/B360 (`EC-USBX`, `PLUG`, `PMC`, `AWAC`), headless-настройка UHD 630 из старой EFI, Intel Ethernet, карта USB для ASUS TUF B360-PRO GAMING и SMBIOS `iMac20,1`, который распознаётся Tahoe. Для OTA включены `RestrictEvents` и `revpatch=sbvmm`; `SecureBootModel` временно отключён.

## Перед обновлением

1. Сделайте полный backup macOS и текущего EFI-раздела.
2. Сначала распакуйте новый архив на **отдельную FAT32-флешку** и проверьте загрузку существующей macOS. Не заменяйте рабочую EFI до успешного теста.
3. В BIOS отключите CSM, Secure Boot, Fast Boot, CFG-Lock и Serial/COM; включите UEFI, Above 4G Decoding, XHCI Hand-off и Execute Disable Bit. SATA должен быть в режиме AHCI. VT-d можно оставить включённым: в конфигурации используется `DisableIoMapper`.
4. При первом запуске выберите **Reset NVRAM**, затем снова загрузитесь с флешки.
5. Проверьте Ethernet, USB, сон и видеоускорение. Только после этого запускайте установщик/обновление Tahoe.

## Важные ограничения

- Точная модель процессора в исходном архиве не указана. Конфигурация рассчитана на Coffee Lake (Intel Core 8/9 поколения), B360 и RX 560. Для другого CPU её нужно корректировать.
- USB-карта взята для этой же модели платы, но ревизия платы и подключение внутренних USB-разъёмов могут отличаться. После загрузки рекомендуется создать собственную карту USB (не более 15 портов на контроллер).
- В Tahoe удалён штатный `AppleHDA`, поэтому аналоговый звук материнской платы может не работать только с AppleALC. Звук через HDMI/DisplayPort RX 560 обычно остаётся доступен. Для аналогового звука понадобится совместимый с вашей версией Tahoe root patch; не применяйте случайные патчеры без backup.
- Если возникает panic в WhateverGreen/AMD-драйвере, временно отключите `WhateverGreen.kext` в `config.plist`: у Tahoe встречаются проблемы с патчингом коннекторов AMD. Для Polaris RX 560 аргумент `agdpmod=pikera` намеренно не добавлен.
- Для диагностики включены verbose-аргументы `-v keepsyms=1 debug=0x100`. После стабильной загрузки их можно удалить из `NVRAM -> Add -> ... -> boot-args`, оставив `revpatch=sbvmm`.
- Идентификаторы SMBIOS/ROM перенесены из исходной EFI для сохранения привязки сервисов. Не публикуйте EFI дальше. При проблемах с iCloud создайте новый комплект SMBIOS для `iMac20,1`, не смешивая старые и новые значения.

Эта EFI является безопасной стартовой конфигурацией, но без проверки на конкретном компьютере невозможно гарантировать работу каждого порта, аудио и сна. Всегда держите загрузочную флешку со старой рабочей EFI.

## Broadcom BCM43602 Wi‑Fi

Для карты `BCM43602 (14E4:43BA)` по пути `PciRoot(0x0)/Pci(0x1C,0x6)/Pci(0x0,0x0)` добавлен `AppleBCMWLANCompanion 1.0.0`. Он загружается только на Tahoe (`MinKernel 25.0.0`), поэтому не конфликтует со штатным драйвером старой macOS.

Перед первым запуском Tahoe установите прошивку из папки `WIFI-BCM43602`: дважды нажмите `install-firmware.command` либо выполните в Terminal:

```bash
cd /путь/к/распакованному/архиву/WIFI-BCM43602
./install-firmware.command
```

В BIOS обязательно включите **Intel VT-d**. В конфигурации `DisableIoMapper=False`, так как новый драйвер Apple и BCMC используют AppleVTD. SIP оставлен включённым; root patch для этого способа не требуется.

Ограничения BCMC: AirDrop/AWDL пока не работает, возможны проблемы со сном. Перед очередным OTA-обновлением Tahoe временно установите `Enabled=False` для `AppleBCMWLANCompanion.kext`, а после завершения обновления включите обратно — иначе на финальной стадии OTA возможен kernel panic. Во время обновления используйте Ethernet.

### Быстрое отключение BCMC перед OTA

Смонтируйте EFI-раздел и дважды нажмите `WIFI-BCM43602/disable-wifi.command`. Скрипт сам найдёт `config.plist`, создаст резервную копию и отключит `AppleBCMWLANCompanion`. После обновления дважды нажмите `enable-wifi.command` и перезагрузитесь. Если EFI имеет нестандартную точку монтирования, можно явно передать файл:

```bash
./WIFI-BCM43602/toggle-bcmc.sh disable /Volumes/EFI/EFI/OC/config.plist
./WIFI-BCM43602/toggle-bcmc.sh enable  /Volumes/EFI/EFI/OC/config.plist
```
